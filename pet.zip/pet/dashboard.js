const carouselInner = document.querySelector('.carousel-inner');
const navDots = document.querySelectorAll('.nav-dot');
let currentIndex = 0; // To track the current slide index
const totalSlides = navDots.length; // Total number of slides

// Function to go to the desired slide
function goToSlide(index) {
    // Ensure index stays within bounds
    currentIndex = index;
    carouselInner.style.transform = `translateX(-${index * 100}%)`;

    // Update the active dot
    navDots.forEach(dot => dot.classList.remove('active'));
    navDots[index].classList.add('active');
}

// Add event listeners to dots for manual navigation
navDots.forEach((dot, index) => {
    dot.addEventListener('click', () => {
        goToSlide(index); // Move to the corresponding slide
    });
});
document.getElementById('category-filter').addEventListener('change', function () {
    const selectedCategory = this.value; // Get selected category
    const petCards = document.querySelectorAll('.pet-card'); // All pet cards

    petCards.forEach(card => {
        if (selectedCategory === 'all' || card.classList.contains(selectedCategory)) {
            card.style.display = 'block'; // Show matching cards
        } else {
            card.style.display = 'none'; // Hide non-matching cards
        }
    });
});
// Filtering Functionality
document.addEventListener("DOMContentLoaded", () => {
    const petTypeSelect = document.getElementById("pet-type");
    const breedSelect = document.getElementById("breed");
    const genderSelect = document.getElementById("gender");
    const ageSelect = document.getElementById("age");
    const petGallery = document.getElementById("pet-gallery");
    const petCards = Array.from(petGallery.getElementsByClassName("pet-card"));

    // Update breed options based on pet type
    petTypeSelect.addEventListener("change", () => {
        const selectedType = petTypeSelect.value;

        // Clear and add breed options dynamically
        breedSelect.innerHTML = `<option value="all">Breed</option>`;
        if (selectedType === "dog") {
            breedSelect.innerHTML += `
                <option value="labrador">Labrador</option>
                <option value="bulldog">Bulldog</option>
                <option value="beagle">Beagle</option>`;
        } else if (selectedType === "cat") {
            breedSelect.innerHTML += `
                <option value="persian">Persian</option>
                <option value="siamese">Siamese</option>`;
        } else if (selectedType === "hen") {
            breedSelect.innerHTML += `
                <option value="leghorn">Leghorn</option>`;
        } else if (selectedType === "duck") {
            breedSelect.innerHTML += `
                <option value="mallard">Mallard</option>`;
        }
    });

    // Filter function
    function filterPets() {
        const selectedType = petTypeSelect.value;
        const selectedBreed = breedSelect.value;
        const selectedGender = genderSelect.value;
        const selectedAge = ageSelect.value;

        petCards.forEach(card => {
            const matchesType = selectedType === "all" || card.classList.contains(selectedType);
            const matchesBreed = selectedBreed === "all" || card.dataset.breed === selectedBreed;
            const matchesGender = selectedGender === "all" || card.dataset.gender === selectedGender;
            const matchesAge = selectedAge === "all" || card.dataset.age === selectedAge;

            if (matchesType && matchesBreed && matchesGender && matchesAge) {
                card.style.display = "block";
            } else {
                card.style.display = "none";
            }
        });
    }

    // Add event listeners for filters
    [petTypeSelect, breedSelect, genderSelect, ageSelect].forEach(select => {
        select.addEventListener("change", filterPets);
    });

    // Initial filter
    filterPets();
});
// Object holding breeds for each category
const breedOptions = {
    dog: ["Labrador", "Bulldog", "Beagle"],
    cat: ["Persian", "Siamese"],
    hen: ["Leghorn"],
    duck: ["Mallard"],
};

// Get references to dropdowns
const petTypeSelect = document.getElementById("pet-type");
const breedSelect = document.getElementById("breed");

// Event listener for category change
petTypeSelect.addEventListener("change", function () {
    const selectedCategory = petTypeSelect.value;

    // Clear existing breed options
    breedSelect.innerHTML = '<option value="all">Breed</option>';

    // Add new breed options if category exists
    if (breedOptions[selectedCategory]) {
        breedOptions[selectedCategory].forEach((breed) => {
            const option = document.createElement("option");
            option.value = breed.toLowerCase();
            option.textContent = breed;
            breedSelect.appendChild(option);
        });
    }
});
